const TAX = 0.18;

module.exports = TAX;